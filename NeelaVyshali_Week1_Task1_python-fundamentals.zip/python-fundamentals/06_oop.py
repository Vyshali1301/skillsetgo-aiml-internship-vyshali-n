"""
Exercise Set 6 - Object-Oriented Programming
Topics: classes, encapsulation, inheritance, polymorphism, class/static methods, dunder methods.
Run: python 06_oop.py
"""
import math

print("--- Exercise 1: Class with attributes and methods ---")
class Student:
    college = "BVRIT"                        # class attribute

    def __init__(self, name, marks):
        self.name = name
        self.marks = marks                   # instance attribute (list)

    def average(self):
        return sum(self.marks) / len(self.marks)

    def __str__(self):
        return f"Student({self.name}, avg={self.average():.1f})"

    @classmethod
    def from_string(cls, text):
        """Alternative constructor: 'Asha:90,85,88'."""
        name, raw = text.split(":")
        return cls(name, [int(m) for m in raw.split(",")])

    @staticmethod
    def is_pass(avg):
        return avg >= 40

s = Student.from_string("Asha:90,85,88")
print(s, "| passed:", Student.is_pass(s.average()), "| college:", Student.college)

print("\n--- Exercise 2: Encapsulation (BankAccount) ---")
class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.__balance = balance             # private attribute

    @property
    def balance(self):
        return self.__balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Deposit must be positive")
        self.__balance += amount

    def withdraw(self, amount):
        if amount > self.__balance:
            raise ValueError("Insufficient funds")
        self.__balance -= amount

acc = BankAccount("Ravi", 1000)
acc.deposit(500)
acc.withdraw(300)
print(acc.owner, "balance:", acc.balance)
try:
    acc.withdraw(5000)
except ValueError as err:
    print("Blocked:", err)

print("\n--- Exercise 3: Inheritance and polymorphism ---")
class Shape:
    def area(self):
        raise NotImplementedError("Subclasses must implement area()")

class Circle(Shape):
    def __init__(self, r):
        self.r = r
    def area(self):
        return math.pi * self.r ** 2

class Rectangle(Shape):
    def __init__(self, w, h):
        self.w, self.h = w, h
    def area(self):
        return self.w * self.h

for shape in (Circle(3), Rectangle(4, 5)):
    print(f"{type(shape).__name__:<10} area = {shape.area():.2f}")

print("\n--- Exercise 4: Dunder methods (__repr__, __eq__, __add__) ---")
class Vector:
    def __init__(self, x, y):
        self.x, self.y = x, y
    def __repr__(self):
        return f"Vector({self.x}, {self.y})"
    def __eq__(self, other):
        return (self.x, self.y) == (other.x, other.y)
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)

print(Vector(1, 2) + Vector(3, 4), "| equal:", Vector(1, 2) == Vector(1, 2))
