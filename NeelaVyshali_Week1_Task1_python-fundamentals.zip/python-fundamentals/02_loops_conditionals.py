"""
Exercise Set 2 - Loops and Conditionals
Topics: for/while, nested loops, if/elif/else, break/continue.
Run: python 02_loops_conditionals.py
"""

print("--- Exercise 1: FizzBuzz (1-15) ---")
for n in range(1, 16):
    if n % 15 == 0:
        print("FizzBuzz", end=" ")
    elif n % 3 == 0:
        print("Fizz", end=" ")
    elif n % 5 == 0:
        print("Buzz", end=" ")
    else:
        print(n, end=" ")
print()

print("\n--- Exercise 2: Digit sum and reverse (while loop) ---")
number = 40719
temp, digit_sum, reversed_num = number, 0, 0
while temp > 0:
    digit = temp % 10
    digit_sum += digit
    reversed_num = reversed_num * 10 + digit
    temp //= 10
print(f"{number}: digit sum = {digit_sum}, reversed = {reversed_num}")

print("\n--- Exercise 3: Prime numbers up to 30 ---")
primes = []
for candidate in range(2, 31):
    is_prime = True
    for divisor in range(2, int(candidate ** 0.5) + 1):
        if candidate % divisor == 0:
            is_prime = False
            break
    if is_prime:
        primes.append(candidate)
print(primes)

print("\n--- Exercise 4: Nested loops (table and pattern) ---")
for i in range(1, 4):
    print(" ".join(f"{i * j:3d}" for j in range(1, 6)))
for row in range(1, 5):
    print(" " * (4 - row) + "*" * (2 * row - 1))

print("\n--- Exercise 5: Grade classifier (if/elif/else) ---")
def grade(marks):
    if marks >= 90:
        return "O"
    elif marks >= 80:
        return "A"
    elif marks >= 70:
        return "B"
    elif marks >= 60:
        return "C"
    return "F"

for m in (95, 84, 71, 65, 40):
    print(f"{m} -> {grade(m)}")

print("\n--- Exercise 6: break and continue ---")
for n in range(1, 20):
    if n % 2 == 0:
        continue          # skip even numbers
    if n > 11:
        break             # stop after 11
    print(n, end=" ")
print()
