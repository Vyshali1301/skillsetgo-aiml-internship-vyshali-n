"""
Exercise Set 5 - Dictionaries
Topics: CRUD, counting, grouping, comprehensions, nested dicts, sorting.
Run: python 05_dictionaries.py
"""

print("--- Exercise 1: CRUD operations ---")
student = {"name": "Asha", "branch": "AIML", "year": 3}
student["cgpa"] = 8.9            # create
student["year"] = 4              # update
del student["branch"]            # delete
print(student, "| missing key ->", student.get("email", "not provided"))
for key, value in student.items():
    print(f"  {key}: {value}")

print("\n--- Exercise 2: Word frequency counter ---")
sentence = "data is the new oil and clean data beats big data"
freq = {}
for word in sentence.split():
    freq[word] = freq.get(word, 0) + 1
top3 = sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:3]
print("frequencies:", freq)
print("top 3      :", top3)

print("\n--- Exercise 3: Grouping and comprehensions ---")
marks = {"Asha": 91, "Ravi": 78, "Meera": 85, "Kiran": 66, "Sana": 88}
groups = {}
for name, score in marks.items():
    label = "distinction" if score >= 85 else "pass"
    groups.setdefault(label, []).append(name)
print("groups     :", groups)
print("squares    :", {n: n ** 2 for n in range(1, 6)})
print("inverted   :", {v: k for k, v in {"a": 1, "b": 2}.items()})

print("\n--- Exercise 4: Nested dictionaries ---")
records = {
    "Asha":  {"maths": 92, "python": 95, "ml": 88},
    "Ravi":  {"maths": 70, "python": 82, "ml": 75},
    "Meera": {"maths": 85, "python": 90, "ml": 80},
}
for name, subjects in records.items():
    print(f"{name:<6} average = {sum(subjects.values()) / len(subjects):.2f}")
defaults = {"theme": "light", "font": 12}
custom = {"font": 16}
print("merged (|) :", defaults | custom)

print("\n--- Exercise 5: Sorting a dictionary ---")
by_score = dict(sorted(marks.items(), key=lambda kv: kv[1], reverse=True))
print("ranked:", by_score)
print("topper:", max(marks, key=marks.get))
