"""
Exercise Set 8 - Exception Handling
Topics: try/except/else/finally, multiple exceptions, custom exceptions, raise, retry logic.
Run: python 08_exceptions.py
"""

print("--- Exercise 1: try / except / else / finally ---")
def safe_divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("  cannot divide by zero")
        return None
    else:
        print("  division succeeded")
        return result
    finally:
        print("  (finally always runs)")

print("10/2 ->", safe_divide(10, 2))
print("10/0 ->", safe_divide(10, 0))

print("\n--- Exercise 2: Handling multiple exception types ---")
for raw in ("25", "abc", None):
    try:
        print(f"  int({raw!r}) =", int(raw))
    except ValueError:
        print(f"  {raw!r} is not a valid integer")
    except TypeError:
        print(f"  {raw!r} has the wrong type")

print("\n--- Exercise 3: File and key errors ---")
try:
    open("does_not_exist.txt")
except FileNotFoundError as err:
    print("  FileNotFoundError:", err)
try:
    {"a": 1}["b"]
except KeyError as err:
    print("  KeyError: missing key", err)

print("\n--- Exercise 4: Custom exceptions ---")
class InvalidAgeError(Exception):
    """Raised when an age is outside 0-120."""

def set_age(age):
    if not 0 <= age <= 120:
        raise InvalidAgeError(f"{age} is not a realistic age")
    return age

for value in (21, 150):
    try:
        print("  valid age:", set_age(value))
    except InvalidAgeError as err:
        print("  InvalidAgeError:", err)

print("\n--- Exercise 5: Retry with simulated inputs ---")
attempts = iter(["ten", "-5", "42"])          # simulated user typing
while True:
    entry = next(attempts)
    try:
        number = int(entry)
        if number < 0:
            raise ValueError("number must be positive")
        print(f"  accepted: {number}")
        break
    except ValueError as err:
        print(f"  rejected {entry!r}: {err}")

print("\n--- Exercise 6: Re-raising with context ---")
def load_config(path):
    try:
        with open(path) as f:
            return f.read()
    except FileNotFoundError as err:
        raise RuntimeError(f"Config missing: {path}") from err

try:
    load_config("settings.cfg")
except RuntimeError as err:
    print("  RuntimeError:", err, "| caused by:", type(err.__cause__).__name__)
