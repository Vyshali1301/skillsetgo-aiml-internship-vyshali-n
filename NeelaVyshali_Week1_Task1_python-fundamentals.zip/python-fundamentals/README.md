# Python Fundamentals Assignment (Week 1 – Task 1.1)

Solved exercises covering variables, loops, functions, OOP, lists, dictionaries, file handling and exceptions in Python, plus a small mini-project that combines all of them.

## 1. Project Objective
Build a strong Python foundation for AI/ML work by solving structured exercises on the eight core topics and applying them in one working program.

## 2. Problem / Dataset
- **Exercises:** 8 topic files, 5–6 solved exercises each.
- **Data:** `data/sample_students.csv` (5 sample student records, used by the file-handling exercises and the mini-project).

## 3. Tools
Python 3.10+ (standard library only: `math`, `csv`, `json`, `pathlib`). No external packages needed.

## 4. Setup
```bash
git clone https://github.com/<your-username>/python-fundamentals.git
cd python-fundamentals
python --version            # 3.10 or newer
python 01_variables_datatypes.py
```
Run any file the same way. `07_file_handling.py` and the mini-project create small output files inside `data/`.

## 5. Method – Folder Structure
| File | Topic | What is covered |
|------|-------|-----------------|
| `01_variables_datatypes.py` | Variables & data types | types, conversion, arithmetic, strings, swapping/unpacking |
| `02_loops_conditionals.py` | Loops & conditionals | FizzBuzz, digit sum, primes, patterns, grade classifier, break/continue |
| `03_functions.py` | Functions | default/keyword args, `*args/**kwargs`, recursion + memoization, lambda/map/filter, scope |
| `04_lists.py` | Lists (+ tuples, sets) | list methods, comprehensions, de-duplication, rotation, transpose, set operations |
| `05_dictionaries.py` | Dictionaries | CRUD, word frequency, grouping, nested dicts, merging, sorting |
| `06_oop.py` | OOP | classes, encapsulation, inheritance, polymorphism, `@classmethod`, dunder methods |
| `07_file_handling.py` | File handling | text, append, CSV, JSON, `pathlib` |
| `08_exceptions.py` | Exceptions | `try/except/else/finally`, custom exceptions, retry logic, `raise ... from` |
| `mini_project_student_manager.py` | Mini-project | OOP + dict + list + CSV/JSON + custom exceptions in one program |
| `outputs/` | Evidence | captured console output of every script |

## 6. Results
Every script runs without errors on Python 3.12. The captured output of each run is saved in [`outputs/`](outputs/). Example from the mini-project:

```
Loaded 5 students

Top 3 students:
  1. Asha   91.67
  2. Sana   87.67
  3. Meera  85.00

Branch averages: {'AIML': 85.0, 'CSE': 85.0, 'ECE': 65.67}
Handled error: No student named 'Zoya'
```

## 7. Screenshots
Terminal screenshots of the runs are stored in [`screenshots/`](screenshots/).

## 8. Next Improvements
- Add `unittest`/`pytest` tests for the functions and the `StudentManager` class.
- Turn the mini-project into an interactive menu (add / search / delete students).
- Replace CSV storage with SQLite.
- Add type hints and a linter (`ruff`) check.

## Author
Neela Vyshali – AI/ML Internship, Week 1 (Skill Set Go EduTech)
