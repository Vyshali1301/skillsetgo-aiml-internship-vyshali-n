"""
Exercise Set 1 - Variables and Data Types
Topics: variable types, type conversion, arithmetic, strings, swapping/unpacking.
Run: python 01_variables_datatypes.py
"""
import math

print("--- Exercise 1: Basic data types ---")
course = "Machine Learning"   # str
credits = 4                   # int
cgpa = 8.75                   # float
is_active = True              # bool
nothing = None                # NoneType
for value in (course, credits, cgpa, is_active, nothing):
    print(f"{value!r:<20} -> {type(value).__name__}")

print("\n--- Exercise 2: Type conversion ---")
print("int('42') + 8       =", int("42") + 8)
print("float('3.14') * 2   =", float("3.14") * 2)
print("str(100) + '%'      =", str(100) + "%")
print("int(3.99)           =", int(3.99), "(truncates, does not round)")
print("bool(0), bool('hi') =", bool(0), bool("hi"))

print("\n--- Exercise 3: Arithmetic ---")
celsius = 37.5
fahrenheit = celsius * 9 / 5 + 32
print(f"{celsius} C = {fahrenheit:.1f} F")
radius = 7
print(f"Circle r={radius}: area={math.pi * radius ** 2:.2f}, circumference={2 * math.pi * radius:.2f}")
print("17 // 5 =", 17 // 5, "| 17 % 5 =", 17 % 5, "| 2 ** 10 =", 2 ** 10)

print("\n--- Exercise 4: Strings ---")
text = "  Python for Machine Learning  "
clean = text.strip()
print("strip/upper   :", clean.upper())
print("replace       :", clean.replace("Python", "NumPy"))
print("split/join    :", "-".join(clean.split()))
print("slicing [0:6] :", clean[0:6], "| reversed:", clean[::-1])
word = "Level"
print(f"'{word}' palindrome? ->", word.lower() == word.lower()[::-1])

print("\n--- Exercise 5: Swapping and unpacking ---")
a, b = 10, 20
a, b = b, a
print("after swap:", a, b)
first, *middle, last = [1, 2, 3, 4, 5]
print("first =", first, "| middle =", middle, "| last =", last)
