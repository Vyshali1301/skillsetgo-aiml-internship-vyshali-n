"""
Exercise Set 4 - Lists (plus tuples and sets)
Topics: list methods, slicing, comprehensions, 2D lists, set operations.
Run: python 04_lists.py
"""

print("--- Exercise 1: Basic list operations ---")
fruits = ["apple", "banana", "cherry"]
fruits.append("mango")
fruits.insert(1, "kiwi")
fruits.remove("banana")
last = fruits.pop()
print("fruits:", fruits, "| popped:", last)
numbers = [5, 2, 9, 1, 7]
print("sorted:", sorted(numbers), "| reversed:", numbers[::-1], "| slice [1:4]:", numbers[1:4])

print("\n--- Exercise 2: List comprehensions ---")
print("squares      :", [x ** 2 for x in range(1, 8)])
print("even squares :", [x ** 2 for x in range(1, 11) if x % 2 == 0])
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print("flattened    :", [item for row in matrix for item in row])

print("\n--- Exercise 3: Remove duplicates, second largest ---")
data = [4, 7, 4, 2, 7, 9, 2, 9, 5]
unique_in_order = []
for item in data:
    if item not in unique_in_order:
        unique_in_order.append(item)
print("unique (order kept):", unique_in_order)
second_largest = sorted(set(data))[-2]
print("second largest     :", second_largest)

print("\n--- Exercise 4: Rotate list and transpose matrix ---")
def rotate_left(items, k):
    k %= len(items)
    return items[k:] + items[:k]

print("rotate [1..6] by 2:", rotate_left([1, 2, 3, 4, 5, 6], 2))
transpose = [[row[i] for row in matrix] for i in range(len(matrix[0]))]
print("transpose:", transpose)

print("\n--- Exercise 5: Tuples and sets ---")
point = (3, 4)                       # tuples are immutable
x, y = point
print("distance from origin:", (x ** 2 + y ** 2) ** 0.5)
python_club = {"Asha", "Ravi", "Meera", "Kiran"}
ml_club = {"Meera", "Kiran", "Sana"}
print("union       :", sorted(python_club | ml_club))
print("intersection:", sorted(python_club & ml_club))
print("difference  :", sorted(python_club - ml_club))
