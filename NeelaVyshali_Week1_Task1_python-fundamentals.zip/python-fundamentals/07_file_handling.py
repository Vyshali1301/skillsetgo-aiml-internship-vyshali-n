"""
Exercise Set 7 - File Handling
Topics: text files, append, line-by-line reading, CSV, JSON, pathlib.
Run: python 07_file_handling.py   (creates files inside the data/ folder)
"""
import csv
import json
from pathlib import Path

DATA = Path(__file__).parent / "data"
DATA.mkdir(exist_ok=True)

print("--- Exercise 1: Write, append and read a text file ---")
notes = DATA / "notes.txt"
with open(notes, "w", encoding="utf-8") as f:
    f.write("Python file handling\n")
    f.write("uses the with statement.\n")
with open(notes, "a", encoding="utf-8") as f:
    f.write("Files close automatically.\n")
print(notes.read_text(encoding="utf-8"))

print("--- Exercise 2: Count lines, words and characters ---")
lines = words = chars = 0
with open(notes, encoding="utf-8") as f:
    for line in f:
        lines += 1
        words += len(line.split())
        chars += len(line)
print(f"lines={lines}, words={words}, characters={chars}")

print("\n--- Exercise 3: Read a CSV and compute averages ---")
with open(DATA / "sample_students.csv", newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
for row in rows:
    scores = [int(row[s]) for s in ("maths", "python", "ml")]
    row["average"] = round(sum(scores) / len(scores), 2)
    print(f"{row['name']:<6} {row['branch']:<4} average = {row['average']}")

print("\n--- Exercise 4: Write results to JSON and read back ---")
report = {r["name"]: r["average"] for r in rows}
json_path = DATA / "students_report.json"
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)
with open(json_path, encoding="utf-8") as f:
    loaded = json.load(f)
print("loaded from JSON:", loaded)

print("\n--- Exercise 5: Write a CSV and inspect the path ---")
out_csv = DATA / "students_ranked.csv"
ranked = sorted(rows, key=lambda r: r["average"], reverse=True)
with open(out_csv, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["rank", "name", "average"])
    for i, r in enumerate(ranked, start=1):
        writer.writerow([i, r["name"], r["average"]])
print("exists:", out_csv.exists(), "| suffix:", out_csv.suffix, "| size (bytes):", out_csv.stat().st_size)
