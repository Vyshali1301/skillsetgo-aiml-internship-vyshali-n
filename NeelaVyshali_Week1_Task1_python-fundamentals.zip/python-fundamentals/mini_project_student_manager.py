"""
Mini Project - Student Records Manager
Combines: classes (OOP), lists, dictionaries, file handling (CSV + JSON), exceptions, functions.
Run: python mini_project_student_manager.py
"""
import csv
import json
from pathlib import Path

DATA = Path(__file__).parent / "data"


class StudentNotFoundError(Exception):
    """Raised when a student name is not in the records."""


class Student:
    def __init__(self, name, branch, scores):
        self.name = name
        self.branch = branch
        self.scores = scores                      # dict: subject -> marks

    @property
    def average(self):
        return sum(self.scores.values()) / len(self.scores)

    def to_dict(self):
        return {"name": self.name, "branch": self.branch,
                "scores": self.scores, "average": round(self.average, 2)}


class StudentManager:
    def __init__(self):
        self.students = {}                        # name -> Student

    def load_csv(self, path):
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                scores = {k: int(v) for k, v in row.items() if k not in ("name", "branch")}
                self.add(Student(row["name"], row["branch"], scores))

    def add(self, student):
        self.students[student.name] = student

    def get(self, name):
        try:
            return self.students[name]
        except KeyError:
            raise StudentNotFoundError(f"No student named {name!r}") from None

    def top(self, n=3):
        return sorted(self.students.values(), key=lambda s: s.average, reverse=True)[:n]

    def branch_summary(self):
        groups = {}
        for s in self.students.values():
            groups.setdefault(s.branch, []).append(s.average)
        return {b: round(sum(v) / len(v), 2) for b, v in groups.items()}

    def save_json(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump([s.to_dict() for s in self.students.values()], f, indent=2)


if __name__ == "__main__":
    manager = StudentManager()
    manager.load_csv(DATA / "sample_students.csv")
    print(f"Loaded {len(manager.students)} students")

    print("\nTop 3 students:")
    for rank, s in enumerate(manager.top(3), start=1):
        print(f"  {rank}. {s.name:<6} {s.average:.2f}")

    print("\nBranch averages:", manager.branch_summary())

    manager.add(Student("Neha", "AIML", {"maths": 80, "python": 87, "ml": 90}))
    print("Added Neha ->", manager.get("Neha").to_dict())

    try:
        manager.get("Zoya")
    except StudentNotFoundError as err:
        print("Handled error:", err)

    manager.save_json(DATA / "manager_report.json")
    print("\nSaved data/manager_report.json")
