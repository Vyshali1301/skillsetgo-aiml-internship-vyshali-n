"""
Exercise Set 3 - Functions
Topics: default/keyword args, *args/**kwargs, recursion, lambda, return values.
Run: python 03_functions.py
"""

print("--- Exercise 1: Default and keyword arguments ---")
def greet(name, greeting="Hello", punctuation="!"):
    """Return a greeting string."""
    return f"{greeting}, {name}{punctuation}"

print(greet("Asha"))
print(greet("Ravi", greeting="Welcome"))
print(greet(punctuation=".", name="Meera"))

print("\n--- Exercise 2: *args and **kwargs ---")
def average(*numbers):
    """Average of any number of values."""
    return sum(numbers) / len(numbers) if numbers else 0

def describe(**info):
    """Print key-value details."""
    return ", ".join(f"{k}={v}" for k, v in info.items())

print("average(4, 8, 15, 16) =", average(4, 8, 15, 16))
print(describe(name="Asha", branch="AIML", year=3))

print("\n--- Exercise 3: Recursion ---")
def factorial(n):
    return 1 if n <= 1 else n * factorial(n - 1)

def fibonacci(n, memo={0: 0, 1: 1}):
    """Fibonacci using a memo dictionary so it stays fast."""
    if n not in memo:
        memo[n] = fibonacci(n - 1) + fibonacci(n - 2)
    return memo[n]

print("factorial(6) =", factorial(6))
print("first 10 Fibonacci:", [fibonacci(i) for i in range(10)])

print("\n--- Exercise 4: Lambda, map, filter, sorted ---")
nums = [3, 8, 1, 12, 7, 6]
print("squares      :", list(map(lambda x: x ** 2, nums)))
print("even numbers :", list(filter(lambda x: x % 2 == 0, nums)))
words = ["banana", "kiwi", "apple", "fig"]
print("sort by len  :", sorted(words, key=lambda w: len(w)))

print("\n--- Exercise 5: Returning multiple values ---")
def summary_stats(values):
    """Return (minimum, maximum, mean) of a list."""
    return min(values), max(values), sum(values) / len(values)

low, high, mean = summary_stats(nums)
print(f"min={low}, max={high}, mean={mean:.2f}")

print("\n--- Exercise 6: Variable scope ---")
counter = 0
def increment():
    global counter
    counter += 1
increment(); increment()
print("counter after two calls:", counter)
